# Avoxshield V2.1 Authentication System

## Overview

The Avoxshield V2.1 web interface now includes a comprehensive authentication system with user management, VPS management, and admin controls. This system provides secure access control and management capabilities for the DDoS protection platform.

## Features

### 🔐 Authentication
- **Login System**: Secure user authentication with password hashing
- **Session Management**: Flask-Login integration for persistent sessions
- **Role-Based Access**: Admin and user roles with different permissions
- **Password Security**: Werkzeug password hashing for secure storage

### 👥 User Management
- **Admin Panel**: Complete user management interface
- **User Creation**: Add new users with customizable permissions
- **Role Assignment**: Assign admin or user roles
- **Permission Control**: Granular permission system (dashboard, metrics, configuration, logs)
- **Expiration Dates**: Set user account expiration dates
- **User Renewal**: Admin can renew expired user accounts

### 🖥️ VPS Management
- **VPS Registration**: Add VPS servers with connection details
- **Connection Testing**: Test SSH connections before adding VPS
- **Encrypted Keys**: Generate secure encrypted keys for each VPS
- **Key Management**: View and copy encrypted keys (admin only)
- **Key Banning**: Disable protection for specific VPS by banning keys
- **Status Tracking**: Monitor VPS connection status

### 🛡️ Security Features
- **Admin Protection**: Admin-only routes and functions
- **Session Security**: Secure session management
- **Password Hashing**: Secure password storage using Werkzeug
- **Access Control**: Role-based access to different features

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    permissions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP
);
```

### VPS Table
```sql
CREATE TABLE vps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ip TEXT NOT NULL,
    user TEXT NOT NULL DEFAULT 'root',
    port INTEGER NOT NULL DEFAULT 22,
    password TEXT NOT NULL,
    encrypted_key TEXT,
    status TEXT DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### User-VPS Relationships
```sql
CREATE TABLE user_vps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    vps_id INTEGER NOT NULL,
    encrypted_key TEXT,
    expires_at TIMESTAMP,
    status TEXT DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (vps_id) REFERENCES vps (id)
);
```

## Default Admin Account

**Username**: `brahim`  
**Password**: `brahim20071`  
**Role**: Admin  
**Permissions**: All permissions  
**Expiration**: Never expires

## Installation & Setup

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the Application
```bash
python app.py
```

### 3. Access the Web Interface
- Open your browser to `http://localhost:5000`
- You will be redirected to the login page
- Use the default admin credentials to log in

### 4. Database Initialization
The database is automatically initialized when the application starts:
- Creates all necessary tables
- Sets up the default admin user
- Establishes database connections

## Usage Guide

### Admin Panel Access
1. Log in with admin credentials
2. Click the "Admin" link in the navigation (crown icon)
3. Access user and VPS management features

### Adding Users
1. Go to Admin Panel
2. Click "Add User" button
3. Fill in user details:
   - Username (required)
   - Email (required)
   - Password (required)
   - Role (user/admin)
   - Permissions (checkboxes)
   - Expiration date (optional)
4. Click "Add User"

### Adding VPS
1. Go to Admin Panel
2. Click "Add VPS" button
3. Fill in VPS details:
   - IP Address (required)
   - Username (default: root)
   - Port (default: 22)
   - Password (required)
4. Test connection (optional)
5. Click "Add VPS"
6. Copy the generated encrypted key

### Managing VPS Keys
- **View Key**: Click "View Key" button to see the encrypted key
- **Copy Key**: Use the "Copy Key" button to copy to clipboard
- **Ban Key**: Click "Ban" button to disable VPS protection
- **Test Connection**: Click "Test" button to verify VPS connectivity

## API Endpoints

### Authentication
- `GET/POST /login` - Login page and authentication
- `GET /logout` - Logout user

### Admin APIs
- `GET /admin` - Admin panel page
- `GET/POST /api/admin/users` - User management
- `GET/POST /api/admin/vps` - VPS management
- `POST /api/admin/test_connection` - Test VPS connection
- `POST /api/admin/ban_key` - Ban VPS key

### Protected Routes
All main application routes now require authentication:
- `/` - Dashboard
- `/metrics` - Metrics page
- `/configuration` - Configuration page
- `/logs` - Logs page
- `/attacks` - Attack history page

## Security Considerations

### Password Security
- All passwords are hashed using Werkzeug's `generate_password_hash()`
- Passwords are never stored in plain text
- Password verification uses `check_password_hash()`

### Session Security
- Flask-Login manages secure sessions
- Sessions are tied to user authentication
- Automatic logout on session expiration

### Access Control
- Admin-only routes are protected with `@login_required` and role checks
- User permissions are stored as JSON and validated
- VPS keys are encrypted and only visible to admins

### Database Security
- SQLite database with proper indexing
- Foreign key constraints for data integrity
- Prepared statements to prevent SQL injection

## Testing

Run the test script to verify the authentication system:
```bash
python test_auth.py
```

This will:
- Test database connection
- Verify admin user creation
- Check password hashing
- Validate table structure

## Troubleshooting

### Common Issues

1. **Database not created**
   - Ensure the application has write permissions in the directory
   - Check that SQLite is available

2. **Login not working**
   - Verify the database was initialized properly
   - Check that the admin user exists
   - Ensure password is correct: `brahim20071`

3. **Admin panel not accessible**
   - Make sure you're logged in as an admin user
   - Check that the user has admin role
   - Verify the admin route is properly protected

4. **VPS connection issues**
   - Verify SSH credentials are correct
   - Check network connectivity to VPS
   - Ensure SSH service is running on VPS

### Debug Mode
Run the application in debug mode for detailed error messages:
```bash
python app.py
```

## Future Enhancements

- [ ] User password reset functionality
- [ ] Email verification for new users
- [ ] Two-factor authentication
- [ ] Audit logging for admin actions
- [ ] Bulk VPS import/export
- [ ] Advanced permission system
- [ ] User activity monitoring
- [ ] Automated VPS health checks

## Support

For issues or questions about the authentication system:
1. Check the application logs
2. Run the test script
3. Verify database integrity
4. Check user permissions and roles 