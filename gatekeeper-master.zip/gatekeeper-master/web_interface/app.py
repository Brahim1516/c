#!/usr/bin/env python3
"""
Avoxshield V2.1 Web Interface
A Flask-based web interface for monitoring and managing the Avoxshield V2.1 DDoS protection system.
"""

from flask import Flask, render_template, jsonify, request, redirect, url_for, flash, session
from flask_socketio import SocketIO, emit
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import json
import time
import subprocess
import psutil
import os
import threading
from datetime import datetime, timedelta
import sqlite3
from collections import defaultdict, deque
import logging
import requests
import secrets

app = Flask(__name__)
app.config['SECRET_KEY'] = 'avoxshield-secret-key-2024'
app.config['DATABASE'] = 'avoxshield.db'

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'

socketio = SocketIO(app, cors_allowed_origins="*", async_mode="gevent")

# User model
class User(UserMixin):
    def __init__(self, id, username, email, role, permissions, created_at, expires_at):
        self.id = id
        self.username = username
        self.email = email
        self.role = role
        self.permissions = permissions
        self.created_at = created_at
        self.expires_at = expires_at

    def is_admin(self):
        return self.role == 'admin'

    def has_permission(self, permission):
        return permission in self.permissions

# VPS model
class VPS:
    def __init__(self, id, ip, user, port, password, encrypted_key, status, created_at):
        self.id = id
        self.ip = ip
        self.user = user
        self.port = port
        self.password = password
        self.encrypted_key = encrypted_key
        self.status = status
        self.created_at = created_at

@login_manager.user_loader
def load_user(user_id):
    db = get_db()
    user_data = db.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    if user_data:
        # Handle permissions field safely
        permissions = []
        if user_data[4] and user_data[4].strip():
            try:
                permissions = json.loads(user_data[4])
            except (json.JSONDecodeError, ValueError):
                permissions = []
        
        return User(
            id=user_data[0],
            username=user_data[1],
            email=user_data[2],
            role=user_data[3],
            permissions=permissions,
            created_at=user_data[5],
            expires_at=user_data[6]
        )
    return None

def get_db():
    db = sqlite3.connect(app.config['DATABASE'])
    db.row_factory = sqlite3.Row
    return db

def init_db():
    """Initialize the database with tables and default admin user"""
    db = get_db()
    
    # Create users table
    db.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            permissions TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP
        )
    ''')
    
    # Create VPS table
    db.execute('''
        CREATE TABLE IF NOT EXISTS vps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip TEXT NOT NULL,
            user TEXT NOT NULL DEFAULT 'root',
            port INTEGER NOT NULL DEFAULT 22,
            password_hash TEXT NOT NULL,
            encrypted_key TEXT,
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create user_vps table for user-VPS relationships
    db.execute('''
        CREATE TABLE IF NOT EXISTS user_vps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            vps_id INTEGER NOT NULL,
            encrypted_key TEXT,
            expires_at TIMESTAMP,
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (vps_id) REFERENCES vps (id)
        )
    ''')
    
    # Check if admin user exists, if not create it
    admin = db.execute('SELECT * FROM users WHERE username = ?', ('brahim',)).fetchone()
    if not admin:
        admin_password_hash = generate_password_hash('brahim20071')
        db.execute('''
            INSERT INTO users (username, email, password_hash, role, permissions, expires_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            'brahim',
            'admin@avoxshield.com',
            admin_password_hash,
            'admin',
            json.dumps(['all']),
            None  # Admin doesn't expire
        ))
    
    db.commit()
    db.close()

# Initialize database on startup
init_db()

# Global variables for storing metrics
metrics_history = {
    'packets_processed': deque(maxlen=1000),
    'packets_dropped': deque(maxlen=1000),
    'attack_attempts': deque(maxlen=1000),
    'cpu_usage': deque(maxlen=1000),
    'memory_usage': deque(maxlen=1000),
    'network_throughput': deque(maxlen=1000),
    'active_flows': deque(maxlen=1000),
    'blocked_ips': deque(maxlen=1000)
}

# Attack tracking
attack_history = deque(maxlen=1000)
active_attacks = {}

# Discord webhook configuration
DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1401937015230169149/WEJCUtxhytdk1N49106OA3YOIv3Y6rlAkRaT8N0Aw2s31turq_jb8BqbeXFeneU-fqHx"

# Configuration
GATEKEEPER_CONFIG = {
    'log_file': '/var/log/gatekeeper/gatekeeper.log',
    'config_dir': '/etc/gatekeeper',
    'status_file': '/var/run/gatekeeper.status',
    'metrics_interval': 5  # seconds
}

# Attack types
ATTACK_TYPES = {
    'SYN_FLOOD': 'SYN Flood',
    'UDP_FLOOD': 'UDP Flood',
    'ICMP_FLOOD': 'ICMP Flood',
    'HTTP_FLOOD': 'HTTP Flood',
    'DNS_AMPLIFICATION': 'DNS Amplification',
    'NTP_AMPLIFICATION': 'NTP Amplification',
    'SNMP_AMPLIFICATION': 'SNMP Amplification',
    'SSDP_AMPLIFICATION': 'SSDP Amplification',
    'CHARGEN_AMPLIFICATION': 'CHARGEN Amplification',
    'SMURF': 'Smurf Attack',
    'FRAGGLE': 'Fraggle Attack',
    'LAND': 'Land Attack',
    'TEARDROP': 'Teardrop Attack',
    'PING_OF_DEATH': 'Ping of Death',
    'SLOWLORIS': 'Slowloris Attack',
    'RUDY': 'RUDY Attack',
    'CUSTOM': 'Custom Attack'
}

def send_discord_alert(attack_data):
    """Send attack alert to Discord webhook"""
    try:
        embed = {
            "title": f"🚨 DDoS Attack Detected - {attack_data['type']}",
            "color": 0xFF0000,
            "fields": [
                {
                    "name": "Attack Type",
                    "value": attack_data['type'],
                    "inline": True
                },
                {
                    "name": "Start Time",
                    "value": attack_data['start_time'],
                    "inline": True
                },
                {
                    "name": "End Time",
                    "value": attack_data.get('end_time', 'Ongoing'),
                    "inline": True
                },
                {
                    "name": "Attack Size",
                    "value": f"{attack_data['size_mbps']:.2f} Mbps",
                    "inline": True
                },
                {
                    "name": "Status",
                    "value": "✅ Blocked" if attack_data.get('blocked', False) else "❌ Not Blocked",
                    "inline": True
                },
                {
                    "name": "Attacker IPs",
                    "value": ", ".join(attack_data.get('attacker_ips', [])),
                    "inline": False
                }
            ],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        payload = {
            "embeds": [embed]
        }
        
        response = requests.post(DISCORD_WEBHOOK_URL, json=payload)
        if response.status_code == 204:
            logging.info("Discord alert sent successfully")
        else:
            logging.error(f"Failed to send Discord alert: {response.status_code}")
            
    except Exception as e:
        logging.error(f"Error sending Discord alert: {e}")

class GatekeeperMonitor:
    def __init__(self):
        self.is_running = False
        self.monitor_thread = None
        self.last_attack_check = time.time()
        
    def start_monitoring(self):
        if not self.is_running:
            self.is_running = True
            self.monitor_thread = threading.Thread(target=self._monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
    
    def stop_monitoring(self):
        self.is_running = False
    
    def _monitor_loop(self):
        while self.is_running:
            try:
                self._collect_metrics()
                self._check_for_attacks()
                socketio.emit('metrics_update', self._get_current_metrics())
                time.sleep(GATEKEEPER_CONFIG['metrics_interval'])
            except Exception as e:
                logging.error(f"Error in monitoring loop: {e}")
    
    def _check_for_attacks(self):
        """Check for new attacks and send alerts"""
        current_time = time.time()
        
        # Simulate attack detection (replace with actual detection logic)
        if current_time - self.last_attack_check > 30:  # Check every 30 seconds
            self.last_attack_check = current_time
            
            # Simulate random attack detection
            if int(current_time) % 300 == 0:  # Every 5 minutes
                attack_type = list(ATTACK_TYPES.keys())[int(current_time) % len(ATTACK_TYPES)]
                attacker_ips = [f"192.168.{int(current_time) % 255}.{int(current_time) % 255}"]
                attack_size = float(current_time % 1000) + 100.0
                
                attack_data = {
                    'id': f"attack_{int(current_time)}",
                    'type': ATTACK_TYPES[attack_type],
                    'attack_type': attack_type,
                    'start_time': datetime.fromtimestamp(current_time).strftime('%Y-%m-%d %H:%M:%S'),
                    'size_mbps': attack_size,
                    'attacker_ips': attacker_ips,
                    'attacked_ports': [80, 443],
                    'blocked': True,
                    'duration_seconds': 60
                }
                
                # Add to attack history
                attack_history.append(attack_data)
                active_attacks[attack_data['id']] = attack_data
                
                # Send Discord alert
                send_discord_alert(attack_data)
                
                # Emit attack notification to web interface
                socketio.emit('attack_detected', attack_data)
                
                # Remove from active attacks after duration
                threading.Timer(attack_data['duration_seconds'], 
                              lambda: self._end_attack(attack_data['id'])).start()
    
    def _end_attack(self, attack_id):
        """End an attack and update status"""
        if attack_id in active_attacks:
            attack_data = active_attacks[attack_id]
            attack_data['end_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            attack_data['duration_seconds'] = int(time.time() - datetime.strptime(attack_data['start_time'], '%Y-%m-%d %H:%M:%S').timestamp())
            
            # Send final Discord alert
            send_discord_alert(attack_data)
            
            # Remove from active attacks
            del active_attacks[attack_id]
            
            # Emit attack ended notification
            socketio.emit('attack_ended', attack_data)
    
    def _collect_metrics(self):
        """Collect real-time metrics from Gatekeeper"""
        timestamp = time.time()
        
        # Get system metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        
        # Simulate Gatekeeper-specific metrics (replace with actual data collection)
        packets_processed = self._get_packets_processed()
        packets_dropped = self._get_packets_dropped()
        attack_attempts = self._get_attack_attempts()
        network_throughput = self._get_network_throughput()
        active_flows = self._get_active_flows()
        blocked_ips = self._get_blocked_ips()
        
        # Store metrics with smoother data
        self._store_smooth_metric('cpu_usage', timestamp, cpu_percent)
        self._store_smooth_metric('memory_usage', timestamp, memory.percent)
        self._store_smooth_metric('packets_processed', timestamp, packets_processed)
        self._store_smooth_metric('packets_dropped', timestamp, packets_dropped)
        self._store_smooth_metric('attack_attempts', timestamp, attack_attempts)
        self._store_smooth_metric('network_throughput', timestamp, network_throughput)
        self._store_smooth_metric('active_flows', timestamp, active_flows)
        self._store_smooth_metric('blocked_ips', timestamp, blocked_ips)
    
    def _store_smooth_metric(self, metric_name, timestamp, value):
        """Store metric with smoothing for better graph appearance"""
        if len(metrics_history[metric_name]) > 0:
            # Apply exponential smoothing for smoother graphs
            last_value = metrics_history[metric_name][-1]['value']
            alpha = 0.3  # Smoothing factor
            smoothed_value = alpha * value + (1 - alpha) * last_value
        else:
            smoothed_value = value
        
        metrics_history[metric_name].append({
            'timestamp': timestamp,
            'value': smoothed_value
        })
    
    def _get_packets_processed(self):
        """Get packets processed count from Gatekeeper logs"""
        try:
            # This would parse actual Gatekeeper logs
            # For now, return simulated data
            return int(time.time() % 10000) + 1000
        except:
            return 0
    
    def _get_packets_dropped(self):
        """Get packets dropped count"""
        try:
            return int(time.time() % 100) + 10
        except:
            return 0
    
    def _get_attack_attempts(self):
        """Get attack attempts count"""
        try:
            return int(time.time() % 50) + 5
        except:
            return 0
    
    def _get_network_throughput(self):
        """Get network throughput in Mbps"""
        try:
            return float(time.time() % 1000) + 100.0
        except:
            return 0.0
    
    def _get_active_flows(self):
        """Get active flows count"""
        try:
            return int(time.time() % 5000) + 500
        except:
            return 0
    
    def _get_blocked_ips(self):
        """Get blocked IPs count"""
        try:
            return int(time.time() % 100) + 20
        except:
            return 0
    
    def _get_current_metrics(self):
        """Get current metrics for real-time updates"""
        return {
            'cpu_usage': metrics_history['cpu_usage'][-1]['value'] if metrics_history['cpu_usage'] else 0,
            'memory_usage': metrics_history['memory_usage'][-1]['value'] if metrics_history['memory_usage'] else 0,
            'packets_processed': metrics_history['packets_processed'][-1]['value'] if metrics_history['packets_processed'] else 0,
            'packets_dropped': metrics_history['packets_dropped'][-1]['value'] if metrics_history['packets_dropped'] else 0,
            'attack_attempts': metrics_history['attack_attempts'][-1]['value'] if metrics_history['attack_attempts'] else 0,
            'network_throughput': metrics_history['network_throughput'][-1]['value'] if metrics_history['network_throughput'] else 0,
            'active_flows': metrics_history['active_flows'][-1]['value'] if metrics_history['active_flows'] else 0,
            'blocked_ips': metrics_history['blocked_ips'][-1]['value'] if metrics_history['blocked_ips'] else 0,
            'timestamp': time.time()
        }

# Initialize monitor
monitor = GatekeeperMonitor()

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        db = get_db()
        user_data = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        
        if user_data and check_password_hash(user_data['password_hash'], password):
            user = User(
                id=user_data['id'],
                username=user_data['username'],
                email=user_data['email'],
                role=user_data['role'],
                permissions=json.loads(user_data['permissions']) if user_data['permissions'] else [],
                created_at=user_data['created_at'],
                expires_at=user_data['expires_at']
            )
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """Logout user"""
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/metrics')
@login_required
def metrics():
    """Metrics page with detailed graphs"""
    return render_template('metrics.html')

@app.route('/configuration')
@login_required
def configuration():
    """Configuration management page"""
    return render_template('configuration.html')

@app.route('/logs')
@login_required
def logs():
    """Log viewer page"""
    return render_template('logs.html')

@app.route('/attacks')
@login_required
def attacks():
    """Attack history page"""
    return render_template('attacks.html')

@app.route('/api/metrics')
def api_metrics():
    """API endpoint for metrics data"""
    return jsonify({
        'packets_processed': list(metrics_history['packets_processed']),
        'packets_dropped': list(metrics_history['packets_dropped']),
        'attack_attempts': list(metrics_history['attack_attempts']),
        'cpu_usage': list(metrics_history['cpu_usage']),
        'memory_usage': list(metrics_history['memory_usage']),
        'network_throughput': list(metrics_history['network_throughput']),
        'active_flows': list(metrics_history['active_flows']),
        'blocked_ips': list(metrics_history['blocked_ips'])
    })

@app.route('/api/attacks')
def api_attacks():
    """API endpoint for attack history"""
    return jsonify({
        'active_attacks': list(active_attacks.values()),
        'attack_history': list(attack_history),
        'attack_types': ATTACK_TYPES
    })

@app.route('/api/attack/<attack_id>')
def api_attack_details(attack_id):
    """API endpoint for specific attack details"""
    # Find attack in history
    for attack in attack_history:
        if attack['id'] == attack_id:
            return jsonify(attack)
    
    # Check active attacks
    if attack_id in active_attacks:
        return jsonify(active_attacks[attack_id])
    
    return jsonify({'error': 'Attack not found'}), 404

@app.route('/api/status')
def api_status():
    """API endpoint for system status"""
    try:
        # Check if Gatekeeper process is running
        gatekeeper_running = False
        for proc in psutil.process_iter(['pid', 'name']):
            if 'gatekeeper' in proc.info['name'].lower():
                gatekeeper_running = True
                break
        
        return jsonify({
            'gatekeeper_running': gatekeeper_running,
            'system_uptime': time.time() - psutil.boot_time(),
            'cpu_count': psutil.cpu_count(),
            'memory_total': psutil.virtual_memory().total,
            'disk_usage': psutil.disk_usage('/').percent,
            'active_attacks_count': len(active_attacks)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/start_gatekeeper', methods=['POST'])
def api_start_gatekeeper():
    """API endpoint to start Gatekeeper"""
    try:
        # This would actually start Gatekeeper
        # subprocess.run(['sudo', 'systemctl', 'start', 'gatekeeper'])
        return jsonify({'status': 'success', 'message': 'Gatekeeper started'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/stop_gatekeeper', methods=['POST'])
def api_stop_gatekeeper():
    """API endpoint to stop Gatekeeper"""
    try:
        # This would actually stop Gatekeeper
        # subprocess.run(['sudo', 'systemctl', 'stop', 'gatekeeper'])
        return jsonify({'status': 'success', 'message': 'Gatekeeper stopped'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/restart_gatekeeper', methods=['POST'])
def api_restart_gatekeeper():
    """API endpoint to restart Gatekeeper"""
    try:
        # This would actually restart Gatekeeper
        # subprocess.run(['sudo', 'systemctl', 'restart', 'gatekeeper'])
        return jsonify({'status': 'success', 'message': 'Gatekeeper restarted'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/block_ip', methods=['POST'])
def api_block_ip():
    """API endpoint to block an IP address"""
    try:
        data = request.get_json()
        ip_address = data.get('ip_address')
        duration = data.get('duration', 3600)  # Default 1 hour
        
        if not ip_address:
            return jsonify({'status': 'error', 'message': 'IP address required'}), 400
        
        # This would actually block the IP in Gatekeeper
        # Implementation would depend on Gatekeeper's API
        
        return jsonify({
            'status': 'success', 
            'message': f'IP {ip_address} blocked for {duration} seconds'
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/unblock_ip', methods=['POST'])
def api_unblock_ip():
    """API endpoint to unblock an IP address"""
    try:
        data = request.get_json()
        ip_address = data.get('ip_address')
        
        if not ip_address:
            return jsonify({'status': 'error', 'message': 'IP address required'}), 400
        
        # This would actually unblock the IP in Gatekeeper
        
        return jsonify({
            'status': 'success', 
            'message': f'IP {ip_address} unblocked'
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/get_logs')
def api_get_logs():
    """API endpoint to get recent logs"""
    try:
        lines = request.args.get('lines', 100, type=int)
        
        # This would read actual Gatekeeper logs
        # For now, return simulated logs
        logs = []
        for i in range(lines):
            logs.append({
                'timestamp': datetime.now() - timedelta(seconds=i*10),
                'level': 'INFO' if i % 3 == 0 else 'WARNING' if i % 5 == 0 else 'ERROR',
                'message': f'Simulated log message {i}'
            })
        
        return jsonify({'logs': logs})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@socketio.on('connect')
def handle_connect():
    """Handle WebSocket connection"""
    print('Client connected')
    emit('connected', {'data': 'Connected to Gatekeeper Web Interface'})

# Admin routes for user and VPS management
@app.route('/admin')
@login_required
def admin_panel():
    """Admin panel page"""
    if not current_user.is_admin():
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('dashboard'))
    return render_template('admin.html')

@app.route('/api/admin/users', methods=['GET', 'POST'])
@login_required
def api_admin_users():
    """API endpoint for user management"""
    if not current_user.is_admin():
        return jsonify({'error': 'Admin privileges required'}), 403
    
    db = get_db()
    
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        role = data.get('role', 'user')
        permissions = data.get('permissions', [])
        expires_at = data.get('expires_at')
        
        try:
            password_hash = generate_password_hash(password)
            db.execute('''
                INSERT INTO users (username, email, password_hash, role, permissions, expires_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (username, email, password_hash, role, json.dumps(permissions), expires_at))
            db.commit()
            return jsonify({'status': 'success', 'message': 'User created successfully'})
        except sqlite3.IntegrityError:
            return jsonify({'error': 'Username or email already exists'}), 400
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    # GET request - return all users
    users = db.execute('SELECT * FROM users ORDER BY created_at DESC').fetchall()
    return jsonify({'users': [dict(user) for user in users]})

@app.route('/api/admin/vps', methods=['GET', 'POST'])
@login_required
def api_admin_vps():
    """API endpoint for VPS management"""
    if not current_user.is_admin():
        return jsonify({'error': 'Admin privileges required'}), 403
    
    db = get_db()
    
    if request.method == 'POST':
        data = request.get_json()
        ip = data.get('ip')
        user = data.get('user', 'root')
        port = data.get('port', 22)
        password = data.get('password')
        
        if not ip or not password:
            return jsonify({'error': 'IP and password are required'}), 400
        
        # Hash the password
        password_hash = generate_password_hash(password)
        
        # Generate encrypted key for VPS
        encrypted_key = secrets.token_urlsafe(32)
        
        try:
            db.execute('''
                INSERT INTO vps (ip, user, port, password_hash, encrypted_key, status)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (ip, user, port, password_hash, encrypted_key, 'active'))
            db.commit()
            return jsonify({
                'status': 'success', 
                'message': 'VPS added successfully',
                'encrypted_key': encrypted_key
            })
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    # GET request - return all VPS (hide passwords)
    vps_list = db.execute('SELECT * FROM vps ORDER BY created_at DESC').fetchall()
    vps_data = []
    for vps in vps_list:
        vps_data.append({
            'id': vps[0],
            'ip': vps[1],
            'user': vps[2],
            'port': vps[3],
            'password': '********',  # Hide password
            'encrypted_key': vps[5],
            'status': vps[6],
            'created_at': vps[7]
        })
    return jsonify({'vps': vps_data})

@app.route('/api/admin/test_connection', methods=['POST'])
@login_required
def api_test_connection():
    """Test VPS connection"""
    if not current_user.is_admin():
        return jsonify({'error': 'Admin privileges required'}), 403
    
    data = request.get_json()
    ip = data.get('ip')
    user = data.get('user', 'root')
    port = data.get('port', 22)
    password = data.get('password')
    
    try:
        # This would actually test SSH connection
        # For now, simulate success
        return jsonify({'status': 'success', 'message': 'Connection successful'})
    except Exception as e:
        return jsonify({'error': f'Connection failed: {str(e)}'}), 500

@app.route('/api/admin/ban_key', methods=['POST'])
@login_required
def api_ban_key():
    """Ban a VPS key"""
    if not current_user.is_admin():
        return jsonify({'error': 'Admin privileges required'}), 403
    
    data = request.get_json()
    vps_id = data.get('vps_id')
    
    db = get_db()
    try:
        db.execute('UPDATE vps SET status = ? WHERE id = ?', ('banned', vps_id))
        db.commit()
        return jsonify({'status': 'success', 'message': 'Key banned successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@socketio.on('disconnect')
def handle_disconnect():
    """Handle WebSocket disconnection"""
    print('Client disconnected')

if __name__ == '__main__':
    # Start monitoring
    monitor.start_monitoring()
    
    # Run the Flask app
    socketio.run(app, host='0.0.0.0', port=80, debug=True) 