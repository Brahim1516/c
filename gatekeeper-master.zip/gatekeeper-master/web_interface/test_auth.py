#!/usr/bin/env python3
"""
Test script for Avoxshield V2.1 authentication system
"""

import sqlite3
import json
from werkzeug.security import generate_password_hash, check_password_hash

def test_database():
    """Test database initialization and admin user creation"""
    print("Testing Avoxshield V2.1 Authentication System")
    print("=" * 50)
    
    # Test database connection
    try:
        db = sqlite3.connect('avoxshield.db')
        db.row_factory = sqlite3.Row
        print("✅ Database connection successful")
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return
    
    # Check if tables exist
    tables = db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    table_names = [table['name'] for table in tables]
    print(f"📋 Found tables: {', '.join(table_names)}")
    
    # Check admin user
    admin = db.execute('SELECT * FROM users WHERE username = ?', ('brahim',)).fetchone()
    if admin:
        print("✅ Admin user 'brahim' exists")
        print(f"   Email: {admin['email']}")
        print(f"   Role: {admin['role']}")
        print(f"   Permissions: {admin['permissions']}")
        
        # Test password
        if check_password_hash(admin['password_hash'], 'brahim20071'):
            print("✅ Admin password is correct")
        else:
            print("❌ Admin password is incorrect")
    else:
        print("❌ Admin user 'brahim' not found")
    
    # Check VPS table
    vps_count = db.execute('SELECT COUNT(*) FROM vps').fetchone()[0]
    print(f"📊 VPS entries: {vps_count}")
    
    db.close()
    print("\n🎉 Authentication system test completed!")

if __name__ == '__main__':
    test_database() 