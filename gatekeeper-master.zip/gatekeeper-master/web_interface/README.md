# Gatekeeper Web Interface

A modern, real-time web interface for monitoring and managing the Gatekeeper DDoS protection system. This interface provides comprehensive monitoring, configuration management, and operational control capabilities.

## Features

### 🎯 **Real-time Monitoring**
- Live system status and metrics
- Real-time packet processing statistics
- Attack detection and blocking metrics
- CPU and memory usage monitoring
- Network throughput analysis

### 📊 **Advanced Analytics**
- Interactive charts and graphs
- Historical data analysis
- Performance trend analysis
- Export capabilities for reporting

### ⚙️ **Configuration Management**
- Network interface configuration
- Security rule management
- Performance tuning settings
- Logging configuration
- Advanced BPF program settings

### 📝 **Log Management**
- Real-time log viewing
- Advanced filtering and search
- Log level filtering
- Export and analysis tools

### 🛡️ **Security Controls**
- IP blocking/unblocking
- Whitelist/blacklist management
- Geographic IP blocking
- Rate limiting configuration

## Installation

### Prerequisites

- Python 3.8 or higher
- Gatekeeper DDoS protection system installed
- Network access to Gatekeeper system

### Setup

1. **Clone or navigate to the web interface directory:**
   ```bash
   cd web_interface
   ```

2. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure the interface:**
   - Edit `app.py` to adjust configuration paths
   - Modify `GATEKEEPER_CONFIG` settings as needed

4. **Start the web interface:**
   ```bash
   python app.py
   ```

5. **Access the interface:**
   - Open your browser to `http://localhost:5000`
   - The interface will automatically connect to Gatekeeper

## Usage

### Dashboard
The main dashboard provides:
- **System Status**: Real-time Gatekeeper service status
- **Quick Actions**: Start/stop/restart Gatekeeper, block/unblock IPs
- **Real-time Metrics**: Live performance indicators
- **Recent Activity**: Latest system events

### Metrics Page
Comprehensive analytics including:
- **Network Throughput**: Bandwidth utilization charts
- **Attack Detection**: DDoS attack monitoring
- **Packet Processing**: Incoming/outgoing packet analysis
- **System Resources**: CPU and memory usage
- **Flow Analysis**: Active connection monitoring

### Configuration Page
Organized into tabs:
- **Network**: Interface and IP configuration
- **Security**: DDoS protection rules and limits
- **Performance**: System tuning parameters
- **Logging**: Log levels and file management
- **Advanced**: BPF programs and low-level settings

### Logs Page
Advanced log management:
- **Real-time Logs**: Live log stream
- **Filtering**: By level, component, or search terms
- **Statistics**: Log entry counts by level
- **Export**: CSV export functionality

## Configuration

### Web Interface Configuration

Edit `app.py` to customize:

```python
GATEKEEPER_CONFIG = {
    'log_file': '/var/log/gatekeeper/gatekeeper.log',
    'config_dir': '/etc/gatekeeper',
    'status_file': '/var/run/gatekeeper.status',
    'metrics_interval': 5  # seconds
}
```

### Security Settings

The interface includes several security features:
- **Authentication**: (Can be extended with Flask-Login)
- **CSRF Protection**: Built-in Flask protection
- **Input Validation**: Client and server-side validation
- **Rate Limiting**: API request limiting

### Network Configuration

Configure network interfaces in the Configuration page:
- **Front Interface**: External-facing network
- **Back Interface**: Internal network
- **IP Addresses**: IPv4 and IPv6 support
- **VLAN Tags**: Network segmentation
- **MTU Settings**: Maximum transmission unit

## API Endpoints

The web interface provides RESTful APIs:

### System Management
- `GET /api/status` - System status
- `POST /api/start_gatekeeper` - Start service
- `POST /api/stop_gatekeeper` - Stop service
- `POST /api/restart_gatekeeper` - Restart service

### Security Management
- `POST /api/block_ip` - Block IP address
- `POST /api/unblock_ip` - Unblock IP address

### Monitoring
- `GET /api/metrics` - System metrics
- `GET /api/get_logs` - Log entries

## Real-time Features

### WebSocket Integration
- **Live Updates**: Real-time metric updates
- **Status Monitoring**: Service status changes
- **Log Streaming**: Live log entries
- **Connection Management**: Automatic reconnection

### Performance Optimization
- **Efficient Polling**: Configurable update intervals
- **Data Caching**: Client-side metric caching
- **Responsive Design**: Mobile-friendly interface
- **Progressive Loading**: Lazy loading of data

## Troubleshooting

### Common Issues

1. **Connection Failed**
   - Check if Gatekeeper is running
   - Verify network connectivity
   - Check firewall settings

2. **Metrics Not Updating**
   - Verify Gatekeeper log file permissions
   - Check metrics collection interval
   - Restart the web interface

3. **Configuration Not Saving**
   - Check file permissions
   - Verify configuration file paths
   - Review error logs

### Debug Mode

Enable debug mode for development:
```python
socketio.run(app, host='0.0.0.0', port=5000, debug=True)
```

### Log Files

Check these log locations:
- Web interface: Console output
- Gatekeeper: `/var/log/gatekeeper/gatekeeper.log`
- System: `/var/log/syslog`

## Development

### Project Structure
```
web_interface/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── README.md             # This file
└── templates/            # HTML templates
    ├── base.html         # Base template
    ├── dashboard.html    # Dashboard page
    ├── metrics.html      # Metrics page
    ├── configuration.html # Configuration page
    └── logs.html         # Logs page
```

### Adding New Features

1. **New API Endpoint:**
   ```python
   @app.route('/api/new_endpoint', methods=['GET'])
   def new_endpoint():
       return jsonify({'data': 'example'})
   ```

2. **New Template:**
   - Create HTML file in `templates/`
   - Extend `base.html`
   - Add route in `app.py`

3. **New Metrics:**
   - Add to `metrics_history` in `app.py`
   - Update `_collect_metrics()` method
   - Add to dashboard template

### Testing

Run basic tests:
```bash
python -m pytest tests/
```

## Security Considerations

### Production Deployment

1. **Use HTTPS**: Configure SSL certificates
2. **Authentication**: Implement user authentication
3. **Access Control**: Restrict access to authorized users
4. **Network Security**: Use firewall rules
5. **Regular Updates**: Keep dependencies updated

### Best Practices

- **Principle of Least Privilege**: Minimal required permissions
- **Input Validation**: Validate all user inputs
- **Error Handling**: Don't expose sensitive information
- **Logging**: Monitor access and errors
- **Backup**: Regular configuration backups

## Performance Tuning

### Web Interface
- **Update Intervals**: Adjust based on system load
- **Data Retention**: Configure metric history size
- **Caching**: Enable browser caching for static assets

### Gatekeeper Integration
- **Log Rotation**: Configure log file rotation
- **Metrics Collection**: Optimize collection frequency
- **Resource Limits**: Set appropriate memory limits

## Support

### Getting Help

1. **Check Logs**: Review error messages
2. **Documentation**: Refer to Gatekeeper documentation
3. **Community**: Join Gatekeeper community forums
4. **Issues**: Report bugs on GitHub

### Contributing

1. **Fork the Repository**
2. **Create Feature Branch**
3. **Make Changes**
4. **Test Thoroughly**
5. **Submit Pull Request**

## License

This web interface is part of the Gatekeeper DDoS protection system and follows the same license terms.

---

**Note**: This web interface is designed to work with the Gatekeeper DDoS protection system. Ensure Gatekeeper is properly installed and configured before using this interface. 