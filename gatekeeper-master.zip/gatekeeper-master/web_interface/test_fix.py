#!/usr/bin/env python3
"""
Test script to verify the JSONDecodeError fix and database functionality
"""

import sqlite3
import json
from werkzeug.security import generate_password_hash, check_password_hash

def test_database():
    """Test database functionality and fix any issues"""
    
    # Connect to database
    db = sqlite3.connect('avoxshield.db')
    db.row_factory = sqlite3.Row
    
    print("Testing database functionality...")
    
    # Check if tables exist
    tables = db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    print(f"Found tables: {[table[0] for table in tables]}")
    
    # Check users table structure
    try:
        users = db.execute("SELECT * FROM users LIMIT 1").fetchall()
        print(f"Users table has {len(users)} records")
        
        # Check if admin user exists
        admin = db.execute("SELECT * FROM users WHERE username = ?", ('brahim',)).fetchone()
        if admin:
            print("Admin user found:")
            print(f"  ID: {admin[0]}")
            print(f"  Username: {admin[1]}")
            print(f"  Email: {admin[2]}")
            print(f"  Role: {admin[3]}")
            print(f"  Permissions: {admin[4]}")
            
            # Test permissions parsing
            try:
                if admin[4] and admin[4].strip():
                    permissions = json.loads(admin[4])
                    print(f"  Parsed permissions: {permissions}")
                else:
                    print("  Permissions: empty or null")
            except (json.JSONDecodeError, ValueError) as e:
                print(f"  Error parsing permissions: {e}")
                # Fix the permissions
                db.execute("UPDATE users SET permissions = ? WHERE username = ?", 
                          (json.dumps(['all']), 'brahim'))
                db.commit()
                print("  Fixed permissions field")
        else:
            print("Admin user not found, creating...")
            admin_password_hash = generate_password_hash('brahim20071')
            db.execute('''
                INSERT INTO users (username, email, password_hash, role, permissions, expires_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                'brahim',
                'admin@avoxshield.com',
                admin_password_hash,
                'admin',
                json.dumps(['all']),
                None
            ))
            db.commit()
            print("Admin user created successfully")
            
    except Exception as e:
        print(f"Error checking users table: {e}")
    
    # Check VPS table
    try:
        vps_count = db.execute("SELECT COUNT(*) FROM vps").fetchone()[0]
        print(f"VPS table has {vps_count} records")
        
        # Check if VPS table has password_hash column
        columns = db.execute("PRAGMA table_info(vps)").fetchall()
        column_names = [col[1] for col in columns]
        print(f"VPS table columns: {column_names}")
        
        if 'password' in column_names and 'password_hash' not in column_names:
            print("Migrating VPS table to use password_hash...")
            # This would need a migration script for existing data
            print("Note: Existing VPS passwords will need to be re-entered")
            
    except Exception as e:
        print(f"Error checking VPS table: {e}")
    
    db.close()
    print("Database test completed!")

if __name__ == "__main__":
    test_database() 